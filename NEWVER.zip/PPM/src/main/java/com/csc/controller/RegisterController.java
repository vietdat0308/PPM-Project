package com.csc.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.csc.dao.UserDao;
import com.csc.model.User;

@Controller
public class RegisterController {
	@Autowired
	private UserDao userDao;
	
	@RequestMapping(value = "/login",method = RequestMethod.GET)
	public String viewRegister(Model model) {
		User userForm = new User();
		model.addAttribute("userForm", userForm);
		return "Login";
	}
	

	@RequestMapping(value = "/login" ,method = RequestMethod.POST)
	public String processRegister(@ModelAttribute("userForm") User user, Model model) {
	
		if(userDao.checkLogin(user.getUsername(), user.getPassword()) != null) {
			return "redirect:result";
		}
		model.addAttribute("message", "Username or password invalid");
		return "Login";
	}
	
	@RequestMapping(value = "/result",method = RequestMethod.GET)
	public String viewAdminPage(Model model) {
		List<User> list = userDao.findAllUser();
		model.addAttribute("list", list);
		return "AdminPage";
	}
	
	public UserDao getUserDao() {
		return userDao;
	}


	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
}
