package com.csc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.csc.dao.UserDao;
import com.csc.model.User;

@Controller
public class deleteController {
	@Autowired
	private UserDao userDao;

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String viewUpdate(@PathVariable int id, Model model) {
		User user = userDao.getUser(id);
		userDao.deleteUser(id);
		List<User> list = userDao.findAllUser();
		model.addAttribute("list", list);
		return "AdminPage";
	}
}
