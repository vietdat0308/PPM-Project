package com.csc.controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.csc.dao.UserDao;
import com.csc.model.User;

@Controller
public class AddController {
	@Autowired
	private UserDao userDao;
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String viewAddUser(Model model) {
		User userForm = new User();
		model.addAttribute("userForm", userForm);
		return "AddUser";
	}
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String processAddUser(@ModelAttribute("userForm")User user, Model model) {
		userDao.createUser(user);
		return "redirect:addcomplete";
	}

	
	@RequestMapping(value = "/addcomplete",method = RequestMethod.GET)
	public String processRegister(Model model) {
		List<User> list = userDao.findAllUser();
		model.addAttribute("list", list);
		return "AdminPage";
	}
	
	
	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
}
