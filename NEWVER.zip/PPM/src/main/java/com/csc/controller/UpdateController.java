package com.csc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.csc.dao.UserDao;
import com.csc.model.User;

@Controller
public class UpdateController {
	@Autowired
	private UserDao userDao;

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String viewUpdate(Model model, HttpServletRequest request) {
		String stt = request.getParameter("userid");
		User userForm = new User();
		userForm = userDao.getUser(Integer.parseInt(stt));
		model.addAttribute("userForm", userForm);
		return "update";
	}
	
	@RequestMapping(value = "/update/update", method = RequestMethod.POST)
	public String processAddUser(@ModelAttribute("userForm")User user, Model model) {
		userDao.updateUser(user);
		return "redirect:updatecomplete";
	}
	
	@RequestMapping(value = "/update/updatecomplete",method = RequestMethod.GET)
	public String processRegister(Model model) {
		List<User> list = userDao.findAllUser();
		model.addAttribute("list", list);
		return "AdminPage";
	}
	
	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}	
}
