package com.csc.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.csc.dao.PatientDao;
import com.csc.dao.UserDao;
import com.csc.model.Patient;
import com.csc.model.User;

@Controller
public class AddController {
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private PatientDao patientDao;
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String viewAddUser(Model model) {
		User userForm = new User();
		model.addAttribute("userForm", userForm);
		return "AddUser";
	}
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String processAddUser(@ModelAttribute("userForm")User user, Model model) {
		userDao.createUser(user);
		return "redirect:adminpage";
	}
	@RequestMapping(value = "/addadd", method = RequestMethod.POST)
	public String viewAddUser1(@ModelAttribute("userForm")User user, Model model) {
		userDao.createUser(user);
		return "redirect:mm";
	}
	
	/*@RequestMapping(value = "/addcomplete",method = RequestMethod.GET)
	public String processRegister(Model model) {
		List<User> list = userDao.findAllUser();
		model.addAttribute("list", list);
		return "AdminPage";
	}*/
	
	@RequestMapping(value = "/addPatient", method = RequestMethod.GET)
	public String viewAddPatient(Model model) {
		Patient userForm = new Patient();
		model.addAttribute("userForm", userForm);
		return "addPatient";
	}

	@RequestMapping(value = "/addPatient", method = RequestMethod.POST)
	public String processAddPatient(@ModelAttribute("userForm")Patient patient, Model model) {
		patientDao.createPatient(patient);
		return "redirect:nursepage";
	}
	
	/*@RequestMapping(value = "/addPatientcomplete",method = RequestMethod.GET)
	public String loadPatientList(Model model) {
		List<Patient> list = patientDao.findAllPatient();
		model.addAttribute("list", list);
		return "redirect:nursepage";
	} */                              
	
	public PatientDao getPatientDao() {
		return patientDao;
	}
	public void setPatientDao(PatientDao patientDao) {
		this.patientDao = patientDao;
	}
	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
}
